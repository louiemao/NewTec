angular-shiro
=============


Demo application
---------
[Address book demo application](http://gnavarro77.github.io/angular-shiro)


Documentation
---------
[Angular shiro documentation](http://gnavarro77.github.io/angular-shiro/docs)