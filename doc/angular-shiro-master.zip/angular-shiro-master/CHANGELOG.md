<a name="0.1.3"></a>
### 0.1.3 (2015-05-03)


#### Features

* **directive:** has-any-permission New Directive, unit tests ([7094ce55](https://github.com/gnavarro77/angular-shiro/commit/7094ce5521d6f2078745d7a1951f48b40450d477))


<a name="0.1.2"></a>
### 0.1.2 (2015-05-03)


#### Features

* **directive:** has-any-permission New Directive, unit tests ([7094ce55](https://github.com/gnavarro77/angular-shiro/commit/7094ce5521d6f2078745d7a1951f48b40450d477))


<a name="0.1.2"></a>
### 0.1.2 (2015-05-03)


#### Features

* **directive:** has-any-permission New Directive, unit tests ([7094ce55](https://github.com/gnavarro77/angular-shiro/commit/7094ce5521d6f2078745d7a1951f48b40450d477))


<a name="0.1.2"></a>
### 0.1.2 (2015-05-03)


#### Features

* **directive:** has-any-permission New Directive, unit tests ([7094ce55](https://github.com/gnavarro77/angular-shiro/commit/7094ce5521d6f2078745d7a1951f48b40450d477))


<a name="0.1.2"></a>
### 0.1.2 (2015-05-03)


#### Features

* **directive:** has-any-permission New Directive, unit tests ([7094ce55](https://github.com/gnavarro77/angular-shiro/commit/7094ce5521d6f2078745d7a1951f48b40450d477))


<a name="0.1.2"></a>
### 0.1.2 (2015-05-03)


#### Features

* **directive:** has-any-permission New Directive, unit tests ([7094ce55](https://github.com/gnavarro77/angular-shiro/commit/7094ce5521d6f2078745d7a1951f48b40450d477))


<a name="0.1.2"></a>
### 0.1.2 (2015-05-03)


#### Features

* **directive:** has-any-permission New Directive, unit tests ([7094ce55](https://github.com/gnavarro77/angular-shiro/commit/7094ce5521d6f2078745d7a1951f48b40450d477))


<a name="0.1.2"></a>
### 0.1.2 (2015-05-02)


#### Features

* **directive:** has-any-permission New Directive, unit tests ([7094ce55](https://github.com/gnavarro77/angular-shiro/commit/7094ce5521d6f2078745d7a1951f48b40450d477))


<a name="0.1.2"></a>
### 0.1.2 (2015-05-02)


#### Features

* **directive:** has-any-permission New Directive, unit tests ([7094ce55](https://github.com/gnavarro77/angular-shiro/commit/7094ce5521d6f2078745d7a1951f48b40450d477))


<a name="0.1.2"></a>
### 0.1.2 (2015-05-02)


#### Features

* **directive:** has-any-permission New Directive, unit tests ([7094ce55](https://github.com/gnavarro77/angular-shiro/commit/7094ce5521d6f2078745d7a1951f48b40450d477))


<a name="0.1.2"></a>
### 0.1.2 (2015-05-02)


#### Features

* **directive:** has-any-permission New Directive, unit tests ([7094ce55](https://github.com/gnavarro77/angular-shiro/commit/7094ce5521d6f2078745d7a1951f48b40450d477))


<a name="0.1.2"></a>
### 0.1.2 (2015-05-02)


#### Features

* **directive:** has-any-permission New Directive, unit tests ([7094ce55](https://github.com/gnavarro77/angular-shiro/commit/7094ce5521d6f2078745d7a1951f48b40450d477))


<a name="0.1.2"></a>
### 0.1.2 (2015-05-02)


#### Features

* **directive:** has-any-permission New Directive, unit tests ([7094ce55](https://github.com/gnavarro77/angular-shiro/commit/7094ce5521d6f2078745d7a1951f48b40450d477))


<a name="0.1.2"></a>
### 0.1.2 (2015-05-02)


#### Features

* **directive:** has-any-permission New Directive, unit tests ([7094ce55](https://github.com/gnavarro77/angular-shiro/commit/7094ce5521d6f2078745d7a1951f48b40450d477))


<a name="0.1.2"></a>
### 0.1.2 (2015-05-02)


#### Features

* **directive:** has-any-permission New Directive, unit tests ([7094ce55](https://github.com/gnavarro77/angular-shiro/commit/7094ce5521d6f2078745d7a1951f48b40450d477))


<a name="0.1.2"></a>
### 0.1.2 (2015-05-02)


#### Features

* **directive:** has-any-permission New Directive, unit tests ([7094ce55](https://github.com/gnavarro77/angular-shiro/commit/7094ce5521d6f2078745d7a1951f48b40450d477))


<a name="0.1.2"></a>
### 0.1.2 (2015-05-02)


#### Features

* **directive:** has-any-permission New Directive, unit tests ([7094ce55](https://github.com/gnavarro77/angular-shiro/commit/7094ce5521d6f2078745d7a1951f48b40450d477))


<a name="0.1.2"></a>
### 0.1.2 (2015-05-02)


#### Features

* **directive:** has-any-permission New Directive, unit tests ([7094ce55](https://github.com/gnavarro77/angular-shiro/commit/7094ce5521d6f2078745d7a1951f48b40450d477))


<a name="0.1.2"></a>
### 0.1.2 (2015-05-02)


#### Features

* **directive:** has-any-permission New Directive, unit tests ([7094ce55](https://github.com/gnavarro77/angular-shiro/commit/7094ce5521d6f2078745d7a1951f48b40450d477))


<a name="0.1.2"></a>
### 0.1.2 (2015-05-02)


#### Features

* **directive:** has-any-permission New Directive, unit tests ([7094ce55](https://github.com/gnavarro77/angular-shiro/commit/7094ce5521d6f2078745d7a1951f48b40450d477))


<a name="0.1.2"></a>
### 0.1.2 (2015-05-02)


#### Features

* **directive:** has-any-permission New Directive, unit tests ([7094ce55](https://github.com/gnavarro77/angular-shiro/commit/7094ce5521d6f2078745d7a1951f48b40450d477))


<a name="0.1.2"></a>
### 0.1.2 (2015-05-02)


#### Features

* **directive:** has-any-permission New Directive, unit tests ([7094ce55](https://github.com/gnavarro77/angular-shiro/commit/7094ce5521d6f2078745d7a1951f48b40450d477))


<a name="0.1.2"></a>
### 0.1.2 (2015-05-02)


#### Features

* **directive:** has-any-permission New Directive, unit tests ([7094ce55](https://github.com/gnavarro77/angular-shiro/commit/7094ce5521d6f2078745d7a1951f48b40450d477))


<a name="0.1.2"></a>
### 0.1.2 (2015-05-02)


#### Features

* **directive:** has-any-permission New Directive, unit tests ([7094ce55](https://github.com/gnavarro77/angular-shiro/commit/7094ce5521d6f2078745d7a1951f48b40450d477))


<a name="0.1.2"></a>
### 0.1.2 (2015-05-02)


#### Features

* **directive:** has-any-permission New Directive, unit tests ([7094ce55](https://github.com/gnavarro77/angular-shiro/commit/7094ce5521d6f2078745d7a1951f48b40450d477))


<a name="0.1.2"></a>
### 0.1.2 (2015-05-02)


#### Features

* **directive:** has-any-permission New Directive, unit tests ([7094ce55](https://github.com/gnavarro77/angular-shiro/commit/7094ce5521d6f2078745d7a1951f48b40450d477))


<a name="0.1.2"></a>
### 0.1.2 (2015-05-02)


#### Features

* **directive:** has-any-permission New Directive, unit tests ([7094ce55](https://github.com/gnavarro77/angular-shiro/commit/7094ce5521d6f2078745d7a1951f48b40450d477))


<a name="0.1.2"></a>
### 0.1.2 (2015-05-02)


#### Features

* **directive:** has-any-permission New Directive, unit tests ([7094ce55](https://github.com/gnavarro77/angular-shiro/commit/7094ce5521d6f2078745d7a1951f48b40450d477))


<a name="0.1.2"></a>
### 0.1.2 (2015-05-02)


#### Features

* **directive:** has-any-permission New Directive, unit tests ([7094ce55](https://github.com/gnavarro77/angular-shiro/commit/7094ce5521d6f2078745d7a1951f48b40450d477))


<a name="0.1.2"></a>
### 0.1.2 (2015-05-02)


#### Features

* **directive:** has-any-permission New Directive, unit tests ([7094ce55](https://github.com/gnavarro77/angular-shiro/commit/7094ce5521d6f2078745d7a1951f48b40450d477))


<a name="0.1.2"></a>
### 0.1.2 (2015-05-02)


#### Features

* **directive:** has-any-permission New Directive, unit tests ([7094ce55](https://github.com/gnavarro77/angular-shiro/commit/7094ce5521d6f2078745d7a1951f48b40450d477))


<a name="0.1.2"></a>
### 0.1.2 (2015-05-02)


#### Features

* **directive:** has-any-permission New Directive, unit tests ([7094ce55](https://github.com/gnavarro77/angular-shiro/commit/7094ce5521d6f2078745d7a1951f48b40450d477))


<a name="0.1.2"></a>
### 0.1.2 (2015-05-02)


#### Features

* **directive:** has-any-permission New Directive, unit tests ([7094ce55](https://github.com/gnavarro77/angular-shiro/commit/7094ce5521d6f2078745d7a1951f48b40450d477))


<a name="0.1.2"></a>
### 0.1.2 (2015-05-02)


#### Features

* **directive:** has-any-permission New Directive, unit tests ([7094ce55](https://github.com/gnavarro77/angular-shiro/commit/7094ce5521d6f2078745d7a1951f48b40450d477))


<a name="0.1.2"></a>
### 0.1.2 (2015-05-02)


#### Features

* **directive:** has-any-permission New Directive, unit tests ([7094ce55](https://github.com/gnavarro77/angular-shiro/commit/7094ce5521d6f2078745d7a1951f48b40450d477))


<a name="0.1.2"></a>
### 0.1.2 (2015-05-02)


#### Features

* **directive:** has-any-permission New Directive, unit tests ([7094ce55](https://github.com/gnavarro77/angular-shiro/commit/7094ce5521d6f2078745d7a1951f48b40450d477))


<a name="0.1.2"></a>
### 0.1.2 (2015-05-02)


#### Features

* **directive:** has-any-permission New Directive, unit tests ([7094ce55](https://github.com/gnavarro77/angular-shiro/commit/7094ce5521d6f2078745d7a1951f48b40450d477))


<a name="0.1.2"></a>
### 0.1.2 (2015-05-02)


#### Features

* **directive:** has-any-permission New Directive, unit tests ([7094ce55](https://github.com/gnavarro77/angular-shiro/commit/7094ce5521d6f2078745d7a1951f48b40450d477))


<a name="0.1.2"></a>
### 0.1.2 (2015-05-02)


#### Features

* **directive:** has-any-permission New Directive, unit tests ([7094ce55](https://github.com/gnavarro77/angular-shiro/commit/7094ce5521d6f2078745d7a1951f48b40450d477))


<a name="0.1.2"></a>
### 0.1.2 (2015-05-02)


#### Features

* **directive:** has-any-permission New Directive, unit tests ([7094ce55](https://github.com/gnavarro77/angular-shiro/commit/7094ce5521d6f2078745d7a1951f48b40450d477))


<a name="0.1.2"></a>
### 0.1.2 (2015-05-02)


#### Features

* **directive:** has-any-permission New Directive, unit tests ([7094ce55](https://github.com/gnavarro77/angular-shiro/commit/7094ce5521d6f2078745d7a1951f48b40450d477))


<a name="0.1.2"></a>
### 0.1.2 (2015-05-02)


#### Features

* **directive:** has-any-permission New Directive, unit tests ([7094ce55](https://github.com/gnavarro77/angular-shiro/commit/7094ce5521d6f2078745d7a1951f48b40450d477))


<a name="0.1.2"></a>
### 0.1.2 (2015-05-02)


#### Features

* **directive:** has-any-permission New Directive, unit tests ([7094ce55](https://github.com/gnavarro77/angular-shiro/commit/7094ce5521d6f2078745d7a1951f48b40450d477))


<a name="0.1.2"></a>
### 0.1.2 (2015-05-02)


#### Features

* **directive:** has-any-permission New Directive, unit tests ([7094ce55](https://github.com/gnavarro77/angular-shiro/commit/7094ce5521d6f2078745d7a1951f48b40450d477))


<a name="0.1.2"></a>
### 0.1.2 (2015-05-02)


#### Features

* **directive:** has-any-permission New Directive, unit tests ([7094ce55](https://github.com/gnavarro77/angular-shiro/commit/7094ce5521d6f2078745d7a1951f48b40450d477))


<a name="0.1.2"></a>
### 0.1.2 (2015-05-02)


#### Features

* **directive:** has-any-permission New Directive, unit tests ([7094ce55](https://github.com/gnavarro77/angular-shiro/commit/7094ce5521d6f2078745d7a1951f48b40450d477))


<a name="0.1.2"></a>
### 0.1.2 (2015-05-02)


#### Features

* **directive:** has-any-permission New Directive, unit tests ([7094ce55](https://github.com/gnavarro77/angular-shiro/commit/7094ce5521d6f2078745d7a1951f48b40450d477))


<a name="0.1.2"></a>
### 0.1.2 (2015-05-02)


#### Features

* **directive:** has-any-permission New Directive, unit tests ([7094ce55](https://github.com/gnavarro77/angular-shiro/commit/7094ce5521d6f2078745d7a1951f48b40450d477))


<a name="0.1.2"></a>
### 0.1.2 (2015-05-02)


#### Features

* **directive:** has-any-permission New Directive, unit tests ([7094ce55](https://github.com/gnavarro77/angular-shiro/commit/7094ce5521d6f2078745d7a1951f48b40450d477))


<a name="0.1.2"></a>
### 0.1.2 (2015-05-02)


#### Features

* **directive:** has-any-permission New Directive, unit tests ([7094ce55](https://github.com/gnavarro77/angular-shiro/commit/7094ce5521d6f2078745d7a1951f48b40450d477))


<a name="0.1.2"></a>
### 0.1.2 (2015-05-02)


#### Features

* **directive:** has-any-permission New Directive, unit tests ([7094ce55](https://github.com/gnavarro77/angular-shiro/commit/7094ce5521d6f2078745d7a1951f48b40450d477))


<a name="0.1.2"></a>
### 0.1.2 (2015-05-02)


#### Features

* **directive:** has-any-permission New Directive, unit tests ([7094ce55](https://github.com/gnavarro77/angular-shiro/commit/7094ce5521d6f2078745d7a1951f48b40450d477))


<a name="0.1.2"></a>
### 0.1.2 (2015-05-02)


#### Features

* **directive:** has-any-permission New Directive, unit tests ([7094ce55](https://github.com/gnavarro77/angular-shiro/commit/7094ce5521d6f2078745d7a1951f48b40450d477))


<a name="0.1.2"></a>
### 0.1.2 (2015-05-02)


#### Features

* **directive:** has-any-permission New Directive, unit tests ([7094ce55](https://github.com/gnavarro77/angular-shiro/commit/7094ce5521d6f2078745d7a1951f48b40450d477))


<a name="0.1.2"></a>
### 0.1.2 (2015-05-02)


#### Features

* **directive:** has-any-permission New Directive, unit tests ([7094ce55](https://github.com/gnavarro77/angular-shiro/commit/7094ce5521d6f2078745d7a1951f48b40450d477))


<a name="0.1.2"></a>
### 0.1.2 (2015-05-02)


#### Features

* **directive:** has-any-permission New Directive, unit tests ([7094ce55](https://github.com/gnavarro77/angular-shiro/commit/7094ce5521d6f2078745d7a1951f48b40450d477))


<a name="0.1.2"></a>
### 0.1.2 (2015-05-02)


#### Features

* **directive:** has-any-permission New Directive, unit tests ([7094ce55](https://github.com/gnavarro77/angular-shiro/commit/7094ce5521d6f2078745d7a1951f48b40450d477))


<a name="0.1.2"></a>
### 0.1.2 (2015-05-02)


#### Features

* **directive:** has-any-permission New Directive, unit tests ([7094ce55](https://github.com/gnavarro77/angular-shiro/commit/7094ce5521d6f2078745d7a1951f48b40450d477))


<a name="0.1.2"></a>
### 0.1.2 (2015-05-01)


#### Features

* **directive:** has-any-permission New Directive, unit tests ([7094ce55](https://github.com/gnavarro77/angular-shiro/commit/7094ce5521d6f2078745d7a1951f48b40450d477))


<a name="0.1.2"></a>
### 0.1.2 (2015-05-01)


#### Features

* **directive:** has-any-permission New Directive, unit tests ([7094ce55](https://github.com/gnavarro77/angular-shiro/commit/7094ce5521d6f2078745d7a1951f48b40450d477))


<a name="0.1.2"></a>
### 0.1.2 (2015-05-01)


#### Features

* **directive:** has-any-permission New Directive, unit tests ([7094ce55](https://github.com/gnavarro77/angular-shiro/commit/7094ce5521d6f2078745d7a1951f48b40450d477))


<a name="0.1.2"></a>
### 0.1.2 (2015-05-01)


#### Features

* **directive:** has-any-permission New Directive, unit tests ([7094ce55](https://github.com/gnavarro77/angular-shiro/commit/7094ce5521d6f2078745d7a1951f48b40450d477))


<a name="0.1.2"></a>
### 0.1.2 (2015-05-01)


#### Features

* **directive:** has-any-permission New Directive, unit tests ([7094ce55](https://github.com/gnavarro77/angular-shiro/commit/7094ce5521d6f2078745d7a1951f48b40450d477))


<a name="0.1.2"></a>
### 0.1.2 (2015-05-01)


#### Features

* **directive:** has-any-permission New Directive, unit tests ([7094ce55](https://github.com/gnavarro77/angular-shiro/commit/7094ce5521d6f2078745d7a1951f48b40450d477))


<a name="0.1.2"></a>
### 0.1.2 (2015-05-01)


#### Features

* **directive:** has-any-permission New Directive, unit tests ([7094ce55](https://github.com/gnavarro77/angular-shiro/commit/7094ce5521d6f2078745d7a1951f48b40450d477))


<a name="0.1.2"></a>
### 0.1.2 (2015-05-01)


#### Features

* **directive:** has-any-permission New Directive, unit tests ([7094ce55](https://github.com/gnavarro77/angular-shiro/commit/7094ce5521d6f2078745d7a1951f48b40450d477))


<a name="0.1.1"></a>
### 0.1.1 (2015-03-11)


#### Features

* **directive:** has-any-permission New Directive, unit tests ([7094ce55](https://github.com/gnavarro77/angular-shiro/commit/7094ce5521d6f2078745d7a1951f48b40450d477))


<a name="0.1.1"></a>
### 0.1.1 (2014-09-07)


#### Features

* **directive:** has-any-permission New Directive, unit tests ([7094ce55](https://github.com/gnavarro77/angular-shiro/commit/7094ce5521d6f2078745d7a1951f48b40450d477))


