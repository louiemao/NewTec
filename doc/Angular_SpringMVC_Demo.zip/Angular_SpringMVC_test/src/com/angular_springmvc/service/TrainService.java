package com.angular_springmvc.service;

import java.util.List;

import com.angular_springmvc.beans.Train;

public interface TrainService {
    public List<Train> queryTrainsList();

    public Train getTrainById(Long id);
    
    public void saveTrain(Train train);
    
    public void removeTrainById(Long id);
    
    public void removeTrainsList();

    public void updateTrain(Train train);
}
