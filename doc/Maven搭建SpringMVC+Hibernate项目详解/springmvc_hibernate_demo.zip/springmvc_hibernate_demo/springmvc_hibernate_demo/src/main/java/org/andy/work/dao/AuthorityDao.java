package org.andy.work.dao;

import org.andy.work.entity.AcctAuthority;

/**  
 * 创建时间：2015-2-6 下午5:20:47  
 * @author andy  
 * @version 2.2  
 * 描述： 权限Dao接口
 */

public interface AuthorityDao extends GenericDao<AcctAuthority, String>{

}
