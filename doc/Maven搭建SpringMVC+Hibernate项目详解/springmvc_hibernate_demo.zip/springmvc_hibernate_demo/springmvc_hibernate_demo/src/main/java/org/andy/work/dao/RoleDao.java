package org.andy.work.dao;

import org.andy.work.entity.AcctRole;

/**  
 * 创建时间：2015-2-6 下午5:20:14  
 * @author andy  
 * @version 2.2  
 * 描述： 角色Dao接口
 */

public interface RoleDao extends GenericDao<AcctRole, String>{

}
